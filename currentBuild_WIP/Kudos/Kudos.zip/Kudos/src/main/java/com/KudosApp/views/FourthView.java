package com.KudosApp.views;

import com.airhacks.afterburner.views.FXMLView;

public class FourthView extends FXMLView{

}
