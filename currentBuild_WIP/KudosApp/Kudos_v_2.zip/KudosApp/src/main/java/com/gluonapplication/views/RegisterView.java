package com.gluonapplication.views;

import com.airhacks.afterburner.views.FXMLView;

public class RegisterView extends FXMLView { 

}