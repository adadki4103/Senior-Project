package com.gluonapplication.views;

import com.airhacks.afterburner.views.FXMLView;

public class GetView extends FXMLView { 

}