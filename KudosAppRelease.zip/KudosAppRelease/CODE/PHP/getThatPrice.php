<?php
$db_name = "kudosAppDB";
$mysql_username = "kudosAdam";
$mysql_password = "Hamham42!";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);


$item_price = $_POST["item_price"];
//$item_price = "Gift Card ($10)";

// Check connection
if ($conn->connect_error) {
    die("Connection failed.");
} 

$sql = "SELECT itemPrice FROM items WHERE itemName = '$item_price'";
$result = $conn->query($sql);
//$sql2 = "SELECT brandEmail FROM brands WHERE brandName = '$row['itemBrand']'";
//$result2 = $conn->query($sql2);

while($row = mysqli_fetch_array($result))
{
  echo $row['itemPrice'];

} 

$conn->close();

?>
