<?php
$db_name = "kudosAppDB";
$mysql_username = "kudosAdam";
$mysql_password = "Hamham42!";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

$itemName = $_POST["item_name"];
$recev = $_POST["name"];
$myCode = $_POST["code"];


if ($conn->connect_error) {
    die("Connection failed.");
} 

$sql = "DELETE FROM pickUp WHERE recName ='$recev' AND itemName = '$itemName' AND genCode = '$myCode'";

if ($conn->query($sql) === TRUE) {
    echo "Pass";
} else {
    echo "Fail";
}
$conn->close();
?>
