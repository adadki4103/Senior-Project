<?php
$db_name = "kudosAppDB";
$mysql_username = "kudosAdam";
$mysql_password = "Hamham42!";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

$user_name = $_GET["user_name"];
$user_pass = $_GET["passwordEntered"];

// Check connection
if ($conn->connect_error) {
    die("Connection failed.");
} 

$sql = "SELECT userName,userPass FROM users WHERE userName = '$user_name' AND userPass ='$user_pass'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

   header("Location: KudosAppLanded.html");
} else {
     header("Location: KudosAppMissed.html");
}
$conn->close();
?>