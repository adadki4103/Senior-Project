<?php
$db_name = "kudosAppDB";
$mysql_username = "kudosAdam";
$mysql_password = "Hamham42!";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

$selectedItem = (int)$_POST["idPicked"];

if ($conn->connect_error) {
    die("Connection failed.");
} 

$sql = "DELETE FROM pickUp WHERE pickUpID='$selectedItem'";

if ($conn->query($sql) === TRUE) {
    echo "Pass";
} else {
    echo "Fail";
}
$conn->close();
?>
