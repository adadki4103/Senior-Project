<?php
$db_name = "kudosAppDB";
$mysql_username = "kudosAdam";
$mysql_password = "Hamham42!";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

$itBrand = $_POST["itemBrand"];
$itName = $_POST["itemName"];
$genCode = $_POST["genCode"];
$recName = $_POST["recName"];


if ($conn->connect_error) {
    die("Connection failed.");
} 

$sql = "INSERT INTO pickUp(recName, itemName, itemBrand, genCode)
VALUES ('$recName','$itName','$itBrand','$genCode')";
if ($conn->query($sql) === TRUE) {
   echo "Success";
}
else {
echo "Fail";
}

?> 