<?php
$db_name = "kudosAppDB";
$mysql_username = "kudosAdam";
$mysql_password = "Hamham42!";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

$user_name = $_POST["user_name"];
$user_pass = $_POST["passwordEntered"];

// Check connection
if ($conn->connect_error) {
    die("Connection failed.");
} 

$sql = "SELECT userName,userPass FROM users WHERE userName = '$user_name' AND userPass ='$user_pass'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    //while($row = $result->fetch_assoc()) {
      //  echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
   // }
   echo "Pass";
} else {
    echo "Fail";
}
$conn->close();
?>
