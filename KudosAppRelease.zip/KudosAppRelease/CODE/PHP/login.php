<?php
$db_name = "kudosAppDB";
$mysql_username = "kudosAdam";
$mysql_password = "Hamham42!";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

$user_name = $_POST["user_name"];
$user_pass = $_POST["passwordEntered"];

// Check connection
if ($conn->connect_error) {
    // die("Connection failed: " . $conn->connect_error);
    die("Connection Failed");
} 

$sql = "INSERT INTO users(userName, userPass)
VALUES ('$user_name','$user_pass')";

if ($conn->query($sql) === TRUE) {
   echo "Success! Try Logging in.";
} else {
//echo "Error: " . $sql . "<br>" . $conn->error;
echo  "User Name Taken";
}

$conn->close();
?>