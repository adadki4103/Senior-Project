<?php
$db_name = "kudosAppDB";
$mysql_username = "kudosAdam";
$mysql_password = "Hamham42!";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

$code = $_POST["theCode"];
//$code = "m5_C:%";

// Check connection
if ($conn->connect_error) {
    die("Connection failed.");
} 

$sql = "SELECT * FROM pickUp WHERE genCode = '$code'";
$result=mysqli_query($conn,$sql);

while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
  echo $row['pickUpID'];
 // echo "\n.\n";
}
$conn->close();
?>
