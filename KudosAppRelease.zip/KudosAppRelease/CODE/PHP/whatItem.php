<?php

$db_name = "kudosAppDB";
$mysql_username = "kudosAdam";
$mysql_password = "Hamham42!";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);


// Check connection
if ($conn->connect_error) {
    die("Connection failed.");
} 
$value = $_POST["value"];
//$value = "Coffee Shop";
$sql ="SELECT * FROM items WHERE itemBrand ='$value'";
$result=mysqli_query($conn,$sql);


// Associative array
while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
  echo $row['itemName'];
  echo "\n.\n";
}
$conn->close();
?>