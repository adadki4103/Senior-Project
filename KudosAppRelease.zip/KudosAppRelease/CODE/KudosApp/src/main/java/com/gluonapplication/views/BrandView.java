package com.gluonapplication.views;

import com.airhacks.afterburner.views.FXMLView;

public class BrandView extends FXMLView { 

}